<!DOCTYPE html>
<html>
	<head>
		<title>Pide tu PAP</title>
		<meta charset="utf-8">
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500">
	</head>
	
	<body>
		<img src="http://papmensajeria.mx/PAP2/mcw_img/pap.jpg" width=15% height=10% />
		<div>
				<div>
					ESTIMADO CLIENTE, POR ESTE MEDIO LE CONFIRMAMOS QUE SU SOLICITUD FUE REGISTRADA EXITOSAMENTE; EN UN MOMENTO NOS PONDREMOS EN CONTACTO CON USTED.<br><br>
					ESTOS SON LOS DATOS MAS IMPORTANTES DE SU SOLICITUD:<BR><br>
				</div>
				<div>
					<B>PUNTO A RECOLECCION:</B><BR><BR>
					NOMBRE DE COTACTO: .'$nombre1'.
					DIRECCION:'.$calle.' '$calle_numero.' '.$int1.' '.$colonia.' '.$delmipio.'
					
				</div>
				<div>
					<B>PUNTO B ENTREGA:</B><BR><BR>
					NOMBRE DE COTACTO: .'$nombre2'.
					DIRECCION:'.$calle2.' '$calle_numero2.' '.$int2.' '.$colonia2.' '.$delmipio2.'
				</div>
		</div>
	</body>
</html>